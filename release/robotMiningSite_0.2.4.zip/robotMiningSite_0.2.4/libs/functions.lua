require "libs.logging"
require "libs.basic-lua-extensions"
require "libs.resources"
require "libs.inventory"

-- adds a recipe which is unlocked when the given technology is researched
function addTechnologyUnlocksRecipe(technologyName, recipeName)
	local tech = data.raw["technology"][technologyName]
	if tech then
		if not tech.effects then
			tech.effects = {}
		end
		table.insert(tech.effects, {type = "unlock-recipe", recipe = recipeName })
	else
		error("Technology "..technologyName.." not found. Did you mean?")
		for name,_ in pairs(data.raw["technology"]) do
			error(" "..name)
		end
	end
end

function overwriteContent(originalTable,newContent)
	if originalTable == nil then
		err("could not overwrite content of nil with new content: "..serpent.block(newContent))
		return
	end
	for k,d in pairs(newContent) do
		originalTable[k]=d
	end
end