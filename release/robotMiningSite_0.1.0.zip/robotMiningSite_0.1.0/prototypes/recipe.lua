data:extend(
{
  {
    type = "recipe",
    name = "robotMiningSite",
    enabled = "false",
    ingredients =
    {
      {"steel-plate", 5},
      {"electronic-circuit", 10},
      {"copper-cable", 5},
    },
    result = "robotMiningSite",
    energy_required = 1,
  },
})