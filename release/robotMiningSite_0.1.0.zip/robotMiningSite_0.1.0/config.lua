debug_master = false -- Master switch for debugging, prints debug stuff into the shell where factorio was started from

updateEveryTicks = 20 -- the next update is triggered X ticks later
updateEveryTicksWaiting = 300 -- no logistics network nearby or no robots available
energyPerMining = 100000 -- Joule