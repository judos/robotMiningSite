require("config")

require("sharedCode.basic-lua-extensions")
require("sharedCode.functions")

require("prototypes.entity")
require("prototypes.items")
require("prototypes.recipe")
require("prototypes.technology")