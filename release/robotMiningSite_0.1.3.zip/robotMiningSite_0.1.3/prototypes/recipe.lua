data:extend(
{
  {
    type = "recipe",
    name = "robotMiningSite",
    enabled = "false",
    ingredients =
    {
      {"steel-plate", 20},
      {"advanced-circuit", 10},
      {"processing-unit", 5},
    },
    result = "robotMiningSite",
    energy_required = 1,
  },
})