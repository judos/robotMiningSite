data:extend({
	{
		type = "item",
		name = "robotMiningSite",
		icon = "__robotMiningSite__/graphics/icons/robotMiningSite.png",
		place_result = "robotMiningSite",
		flags = {"goes-to-quickbar"},
    subgroup = "logistic-network",
    order = "c[signal]-b[robotMiningSite]",
		category = "crafting",
		stack_size = 50,
	},
})