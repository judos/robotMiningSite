require("prototypes.generatedItemSubgroup")

data:extend({
  {
    type = "item",
    name = "fake-generated-item",
    icon = "__robotMiningSite__/graphics/icons/fakeItem.png",
    subgroup = "generated",
    order = "zzz",
	icon_size = 64,
    stack_size = 10000,
  }
})
