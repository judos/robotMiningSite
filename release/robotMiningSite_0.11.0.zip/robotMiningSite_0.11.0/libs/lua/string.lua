require "libs.logging"

function string.starts(str,prefix)
  return string.sub(str,1,string.len(prefix))==prefix
end

function string.ends(str,suffix)
   return suffix=='' or string.sub(str,-string.len(suffix))==suffix
end

-- See: http://lua-users.org/wiki/MakingLuaLikePhp
function split(str,divider) -- credit: http://richard.warburton.it
  if divider=='' then return false end
  local pos,arr = 0,{}
  -- for each divider found
  for st,sp in function() return str:find(divider,pos,true) end do
    table.insert(arr,str:sub(pos,st-1)) -- Attach chars left of current divider
    pos = sp + 1 -- Jump past current divider
  end
  table.insert(arr,str:sub(pos)) -- Attach chars right of last divider
  return arr
end

-- e.g. formatWith("%time - %msg",{time = "10pm", msg = "Hello"} -> "10pm - Hello"
function formatWith(formatStr,parameters)
	if not parameters then
		err("ERROR: missing parameters for formatWith in libs.lua.string")
		parameters = {}
	end
	repeat
		local before = formatStr
		local tag = formatStr:match("%%(%a+)")
		if tag then
			if not parameters[tag] then parameters[tag]=tag end
			formatStr = formatStr:gsub("%%"..tag, parameters[tag])
		end
	until tag == nil or before == formatStr
	return formatStr
end

local format = string.format

-- converts arbitrary version string X.Y.Z into xx.yy.zz for comparison
-- Parameters: string in format X.Y.Z
-- Returns: string in format xx.yy.zz
function format_version(version_string)
  if version_string then
    local X, Y, Z = version_string:match("(%d+).(%d+).(%d+)")
    if tonumber(X) and tonumber(Y) and tonumber(Z) then
      return format("%02d.%02d.%02d", X, Y, Z)
    end
  end
end
