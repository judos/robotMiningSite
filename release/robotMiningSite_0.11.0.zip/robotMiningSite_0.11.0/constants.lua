
modVersion = "00.10.02"
modName = "robotMiningSite"
fullModName = "robotMiningSite"

libLog.testing = false -- enable logging
libLog.always_player_print = false
