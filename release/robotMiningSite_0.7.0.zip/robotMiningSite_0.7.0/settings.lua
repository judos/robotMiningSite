data:extend(
{
  {
    type = "bool-setting",
    name = "robotMiningSite_EasyT1",
    setting_type = "startup",
    default_value = false,
  },
 }
 )