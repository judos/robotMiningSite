
modVersion = "0.7.0"
modName = "robotMiningSite"
fullModName = "robotMiningSite"

libLog.testing = false -- enable logging
libLog.always_player_print = false
