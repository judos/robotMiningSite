updateEveryTicks = 20 -- the next update is triggered X ticks later
updateEveryTicksWaiting = 300 -- no logistics network nearby or no robots available