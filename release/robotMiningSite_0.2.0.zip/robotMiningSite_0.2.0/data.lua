require "config"
require "libs.functions"

require "prototypes.technology"

require "prototypes.miningRoboport"
require "prototypes.miningRobot"
require "prototypes.robotMiningSite"
require "prototypes.robotMiningSite-old"
require "prototypes.invisibleStorageChest"
require "prototypes.logisticDeciderCombinator"