require("prototypes.generatedItemSubgroup")

data:extend({
  {
    type = "item",
    name = "empty-item",
    icon = "__robotMiningSite__/graphics/icons/emptyItem.png",
    flags = {"goes-to-main-inventory"},
    subgroup = "generated",
    order = "emptyItem",
    stack_size = 10000,
  }
})
