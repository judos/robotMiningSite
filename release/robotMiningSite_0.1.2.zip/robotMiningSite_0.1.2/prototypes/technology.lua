addTechnologyUnlocksRecipe("construction-robotics","robotMiningSite")

