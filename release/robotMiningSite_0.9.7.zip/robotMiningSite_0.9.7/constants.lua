
modVersion = "0.9.6"
modName = "robotMiningSite"
fullModName = "robotMiningSite"

libLog.testing = false -- enable logging
libLog.always_player_print = false
