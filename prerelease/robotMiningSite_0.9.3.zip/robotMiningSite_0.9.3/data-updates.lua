require "prototypes.miningRobot-recipe-updates"
