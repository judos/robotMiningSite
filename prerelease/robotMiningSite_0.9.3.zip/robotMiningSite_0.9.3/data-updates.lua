if mods["boblogistics"] then
  require "prototypes.miningRobot-recipe-updates"
end