data:extend({
  {
    type = "item-subgroup",
    name = "mining-robots",
    group = "bob-logistics",
    order = "f-a3",
  },
  {
    type = "item-subgroup",
    name = "mining-roboport",
    group = "bob-logistics",
    order = "f-a4",
  }
})