data:extend({
	{
    type = "item-group",
    name = "generated",
    order = "zzz",
	inventory_order = "zzz",
    icon = "__robotMiningSite__/graphics/icons/generated.png",
	icon_size= 64
  },
	{
    type = "item-subgroup",
    name = "generated",
    group = "generated",
    order = "zzz",
  }
})